package lab;
import java.util.Scanner;
import java.util.ArrayList;

public class Library {
	private Scanner input;
	private ArrayList<Book> books;
	public Library() {
		input = new Scanner(System.in);
		books = new ArrayList<Book>();
	}
	public void addBook() {
		System.out.print("Enter book title: ");
		String title = input.nextLine();
		books.add(new Book(title));
		System.out.print(title + " has been added.");
	}
	public void borrowBook() {
		System.out.print("Enter the book title you would like to borrow: ");
		String title = input.nextLine();
		
		for (Book book : books) {
			if (book.getTitle().equalsIgnoreCase(title)) {
				book.borrowBook();
				return;
			}
		}
		System.out.print("Book is not found.");
	}
	public void returnBook() {
		System.out.print("Enter a book title to return: ");
		String title = input.nextLine();
		
		for (Book book : books) {
			if (book.getTitle().equalsIgnoreCase(title)) {
				book.returnBook();
				return;
			}
		}
		System.out.print("Book is not found.");
	}
	public void displayAllAvailableBooks() {
		System.out.print("\nAvailable books: ");
		boolean found = false;
		
		for (Book book : books) {
			if (!book.isBorrowed()) {
				System.out.print("\n- " + book.getTitle());
				found = true;
			}
		}
		if (!found) {
			System.out.print("No books have been found");
		}
	}
	public void searchBook() {
		System.out.print("Enter title to search: ");
		String title = input.nextLine();
		
		for (Book book : books) {
			if(book.getTitle().equalsIgnoreCase(title)) {
				System.out.print("Found title: " + book.getTitle() + "\nID: " + book.getId() + "\nStatus" + (book.isBorrowed() ?" - Borrowed" : " - Available"));
			}
		}
		System.out.print("");
	}
	public void menu() {
		int choice;
		do {
			System.out.print("\n====== Library Menu ======");
            System.out.print("\n1. Add Book");
            System.out.print("\n2. Borrow Book");
            System.out.print("\n3. Return Book");
            System.out.print("\n4. Display Available Books");
            System.out.print("\n5. Search for Title");
            System.out.print("\n6. Exit");
            System.out.print("\nEnter choice: ");
            while (!input.hasNextInt()) {
            	System.out.print("Invalid input. Try again");
            	input.next();
            }
            choice = input.nextInt();
            input.nextLine();
            
            switch (choice) {
            case 1:
            	addBook();
            	break;
            case 2:
            	borrowBook();
            	break;
            case 3:
            	returnBook();
            	break;
            case 4:
            	displayAllAvailableBooks();
            	break;
            case 5:
            	searchBook();
            	break;
            case 6:
            	System.out.print("Exiting.");
            	break;
            default:
            	System.out.print("Invalid choice.");
            }
		} while (choice != 6);
	}
	public static void main(String [] args) {
		Library library = new Library();
		library.menu();
	}
}