package lab;

public class Book {
	private String title;
	private boolean isBorrowed;
	private int id;
	private static int counter = 1;
	public Book(String title) {
		this.title = title;
		this.isBorrowed = false;
		this.id = counter++;
	}
	public void borrowBook() {
		if (!isBorrowed) {
			isBorrowed = true;
			System.out.print("You borrowed: " + title);
		} else {
			System.out.print("This title is already borrowed");
			}
		}
	public void returnBook() {
		if (isBorrowed) {
			isBorrowed = false;
			System.out.print("You returned: " + title);
		} else {
			System.out.print("Book was not borrowed.");
		}
	}
	public String getTitle() {
		return title;
	}
	public boolean isBorrowed() {
		return isBorrowed;
	}
	public int getId() {
		return id;
	}
}