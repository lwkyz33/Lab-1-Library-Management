/**
 * 
 */
/**
 * 
 */
module Lab1 {
}